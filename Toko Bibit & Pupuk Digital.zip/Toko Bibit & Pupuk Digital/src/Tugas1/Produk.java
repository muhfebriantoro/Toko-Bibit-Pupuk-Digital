/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas1;

/**
 *
 * @author Febri
 */
// Nama File: Produk.java
public class Produk {
    public String namaProduk;
    public double hargaProduk;
    public String kategori;

    public Produk(String nama, double harga, String kat) {
        this.namaProduk = nama;
        this.hargaProduk = harga;
        this.kategori = kat;
    }
}  