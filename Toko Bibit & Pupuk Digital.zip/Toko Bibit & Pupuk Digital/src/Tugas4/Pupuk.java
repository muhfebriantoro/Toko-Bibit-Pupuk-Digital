/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas4;

/**
 *
 * @author Febri
 */
public class Pupuk extends Produk {
    private String beratKilo;

    public void setPupuk(String nama, String kilo) {
       
        setNama(nama);
        this.beratKilo = kilo;

        if (kilo.equalsIgnoreCase("5 kg")) setHarga(50000);
        else if (kilo.equalsIgnoreCase("10 kg")) setHarga(100000);
    }
    
    // Getter
    public String getKilo() { 
        return beratKilo; 
    }

    // Setter tambahan
    public void setKilo(String beratKilo) {
        this.beratKilo = beratKilo;
    }
}