/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas7;

/**
 *
 * @author Febri
 */
public abstract class Produk {
    String nama; 
    String jenis;
    double harga;

//    public void tampilProduk() {
//        System.out.println("Nama Produk : " + nama);
//        System.out.println("Harga       : " + harga);
//    }
        
    public void setProduk(String nama, String jenis) {
        this.nama = nama;
        this.jenis = jenis;

    }
}
