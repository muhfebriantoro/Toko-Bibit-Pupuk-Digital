/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas3;

/**
 *
 * @author Febri
 */
public class Pupuk extends Produk {
    String beratKilo;

    public void setPupuk(String nama, String kilo) {
        this.nama = nama;
        this.beratKilo = kilo;

        if (kilo.equalsIgnoreCase("5 kg")) this.harga = 50000;
        else if (kilo.equalsIgnoreCase("10 kg")) this.harga = 100000;
    }
    
    public String getKilo() { return beratKilo; }
}

