/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas8;

/**
 *
 * @author Febri
 */
public abstract class Produk {
    String nama; 
    String jenis;
    double harga;
        
    public void setProduk(String nama, String jenis) {
        this.nama = nama;
        this.jenis = jenis;

    }
}
