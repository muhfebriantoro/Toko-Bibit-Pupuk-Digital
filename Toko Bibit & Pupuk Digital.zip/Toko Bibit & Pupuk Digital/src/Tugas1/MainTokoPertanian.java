/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas1;

/**
 *
 * @author Febri
 */
// Nama File: MainTokoPertanian.java

public class MainTokoPertanian {
    public static void main(String[] args) {
        
        Produk produk1 = new Produk("Bibit Cabai", 5000, "Pangan");
        System.out.println("Nama Produk : " + produk1.namaProduk);
        System.out.println("Harga       : Rp " + produk1.hargaProduk);
        System.out.println("Kategori    : " + produk1.kategori);
        System.out.println("--------------------------");

        Produk produk2 = new Produk("Pupuk Organik", 10000, "10kg");
        System.out.println("Nama Produk : " + produk2.namaProduk);
        System.out.println("Harga       : Rp " + produk2.hargaProduk);
        System.out.println("Kategori    : " + produk2.kategori);
        System.out.println("--------------------------");
    }
}
