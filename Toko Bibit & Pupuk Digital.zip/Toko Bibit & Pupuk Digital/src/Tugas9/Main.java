/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas9;

/**
 *
 * @author Febri
 */
public class Main {
    public static void main(String[] args) {
        Bibit bibitPesanan = new Bibit();

        System.out.println("=== SISTEM PEMBELIAN BIBIT TANAMAN ===");
             
        String namaBibit = "Bibit Sawit";
        String jenisTanaman = "Pohon";
        int jumlahBeli = 2;
        
        bibitPesanan.setProduk(namaBibit, jenisTanaman);

        
        System.out.println("Nama Produk   : " + bibitPesanan.namaBibit());
        System.out.println("Jenis Tanaman : " + bibitPesanan.JenisTanaman());
        System.out.println("Detail Produk : " + bibitPesanan.getInfoDetail());
        System.out.println("Harga Satuan  : Rp " + bibitPesanan.harga); 
        System.out.println("Pajak Jenis   : Rp " + bibitPesanan.Pajak());
        System.out.println("Jumlah Beli   : " + jumlahBeli + " pcs");
        System.out.println("--------------------------------------");
     
            double totalHargaKotor = bibitPesanan.getTotalHarga(jumlahBeli);

            double potonganDiskon = bibitPesanan.hitungDiskon(totalHargaKotor);

            double totalBayar = totalHargaKotor - potonganDiskon;

            System.out.println("=== RINCIAN PEMBAYARAN ===");
            System.out.println("Subtotal (+ Pajak)       : Rp " + totalHargaKotor);
            System.out.println("Diskon yang Didapat      : Rp " + potonganDiskon);
            System.out.println("Total yang Harus Dibayar : Rp " + totalBayar);
            System.out.println("=====================================");
    }
}