/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas6;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk{

    String jenisTanaman;
    String namaBibit;
    double pajak, jumlah;
            
    @Override
    public void setProduk(String nama, String jenis){
        this.namaBibit = nama;
        this.jenisTanaman = jenis;     
        
        // harga berdasarkan bibit 
        if (namaBibit.equalsIgnoreCase("Bibit Cabai")) {
            this.harga = 5000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Sawit")) {
            this.harga = 80000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Anggrek")) {
            this.harga = 10000;
        }

        // pajak berdasarkan jenis 
        if (jenis.equalsIgnoreCase("Pohon")) {
            this.pajak = 5000;
        } else if (jenis.equalsIgnoreCase("Pangan")) {
            this.pajak = 2000;
        } else if (jenis.equalsIgnoreCase("Hias")) {
            this.pajak = 1000;
        } else {
            this.pajak = 0;
        }
        
    }
    public String namaBibit(){
        return namaBibit;
    }
     public double getTotalHarga(int jumlah) {
        return (this.harga * jumlah) + this.pajak;
    }
    public String JenisTanaman(){
       return jenisTanaman;
    }
    public double Pajak(){
       return pajak;
    }
}