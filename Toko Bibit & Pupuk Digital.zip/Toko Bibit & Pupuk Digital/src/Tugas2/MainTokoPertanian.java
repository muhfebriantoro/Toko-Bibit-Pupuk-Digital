/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas2;

/**
 *
 * @author Febri
 */
// Nama File: MainTokoPertanian.java

public class MainTokoPertanian {
    public static void main(String[] args) {
        // Menggunakan konstruktor untuk mengisi data langsung saat instansiasi
        Produk produk1 = new Produk("Bibit Cabai", 5000, "Pangan");
        Produk produk2 = new Produk("Pupuk Urea Premium", 50000, "5kg");

        System.out.println("=== TOKO BIBIT DAN PUPUK ONLINE ===");
        System.out.println("Nama Produk : " + produk1.namaProduk);
        System.out.println("Harga       : Rp " + produk1.hargaProduk);
        System.out.println("Kategori    : " + produk1.kategori);
        System.out.println("--------------------------");
        
        System.out.println("Nama Produk : " + produk2.namaProduk);
        System.out.println("Harga       : Rp " + produk2.hargaProduk);
        System.out.println("Kategori    : " + produk2.kategori);
        System.out.println("--------------------------");
    }
}
