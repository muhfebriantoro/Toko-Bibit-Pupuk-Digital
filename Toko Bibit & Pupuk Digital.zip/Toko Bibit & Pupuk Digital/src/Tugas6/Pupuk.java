/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas6;

/**
 *
 * @author Febri
 */
class Pupuk extends Produk {
  
    String namaPupuk;
    String kilo;
    
    @Override
    public void setProduk(String nama, String jenis){
        this.namaPupuk = nama;
        this.kilo = jenis;
                
        // ===== Tentukan harga berdasarkan berat =====
        if (kilo.equalsIgnoreCase("5 kg")) {
            this.harga = 50000;
        } else if (kilo.equalsIgnoreCase("10 kg")) {
            this.harga = 100000;
        }
    }   
}
