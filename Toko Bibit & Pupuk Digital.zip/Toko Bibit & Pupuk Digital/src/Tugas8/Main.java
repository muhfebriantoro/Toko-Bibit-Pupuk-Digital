/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas8;

/**
 *
 * @author Febri
 */
public class Main {
    public static void main(String[] args) {
        Produk pro1 = new Bibit(); 
               
        ((Bibit) pro1).getTotalHarga(2);
        
        pro1.setProduk("Bibit Cabai", "Pangan"); 

        System.out.println("--- Detail Produk: Bibit ---");
        System.out.println("Nama Produk    : " + pro1.nama); // Mengakses variabel Superclass
        System.out.println("Harga Total    : " + pro1.harga); // Mengakses variabel Superclass

        System.out.println("Jenis Tanaman  : " + ((Bibit) pro1).JenisTanaman());
        System.out.println("Pajak Terkena  : " + ((Bibit) pro1).Pajak());
        System.out.println("---------------------------------------------\n");

        Produk pro2 = new Pupuk(); 
        
        pro2.setProduk("Pupuk Kompos", "10 kg"); 

        System.out.println("--- Detail Produk: Pupuk ---");
        System.out.println("Nama Produk    : " + pro2.nama);
        System.out.println("Harga Total    : " + pro2.harga);
        
        System.out.println("Ukuran Berat   : " + ((Pupuk) pro2).kilo);
        System.out.println("---------------------------------------------");
    }
}
