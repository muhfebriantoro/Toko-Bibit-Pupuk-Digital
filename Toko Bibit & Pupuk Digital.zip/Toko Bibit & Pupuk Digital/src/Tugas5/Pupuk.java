/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Febri
 */
class Pupuk extends Produk {
  
    String namaPupuk;
    String kilo;
    
    public void setPupuk(String namaPupuk, String kilo) {
        this.namaPupuk = namaPupuk;
        this.kilo = kilo;
                
      
        if (kilo.equalsIgnoreCase("5 kg")) {
            this.harga = 50000;
        } else if (kilo.equalsIgnoreCase("10 kg")) {
            this.harga = 100000;
        }   
    }
    public void setPupuk(String nama, String kilo, int jumlahBeli) {
        this.setPupuk(nama, kilo); 
        
        // Mengalikan harga dasar kemasan dengan jumlah beli
        this.harga = this.harga * jumlahBeli; 
    }
}
