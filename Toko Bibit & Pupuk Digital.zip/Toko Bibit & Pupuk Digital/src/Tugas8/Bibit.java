/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas8;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk{
    String namaBibit, jenisTanaman;
    double pajak;
            
    public void setProduk(String namaBibit, String jenis){
        this.namaBibit = namaBibit;
        this.jenisTanaman = jenis;     
     
        if (namaBibit.equalsIgnoreCase("Bibit Cabai")) {
            this.harga = 5000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Sawit")) {
            this.harga = 80000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Anggrek")) {
            this.harga = 10000;
        }

        if (jenis.equalsIgnoreCase("Pohon")) {
            this.pajak = 5000;
        } else if (jenis.equalsIgnoreCase("Pangan")) {
            this.pajak = 2000;
        } else if (jenis.equalsIgnoreCase("Hias")) {
            this.pajak = 1000;
        } else {
            this.pajak = 0;
        }
    }
 
    public double getTotalHarga(int jumlah) {
        return (this.harga * jumlah) + this.pajak;
    }   
    public String JenisTanaman(){
       return jenisTanaman;
    }
    public double Pajak(){
       return pajak;
    }
    public String namaBibit(){
        return namaBibit;
    }
}