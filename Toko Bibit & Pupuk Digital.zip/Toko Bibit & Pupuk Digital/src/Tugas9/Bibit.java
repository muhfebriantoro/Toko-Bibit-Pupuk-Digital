/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas9;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk implements Diskon, DeskripsiProduk, StokBarang{
    String namaBibit, jenisTanaman;
    double pajak;
            
    @Override
    public void setProduk(String namaBibit, String jenis){
        this.namaBibit = namaBibit;
        this.jenisTanaman = jenis;     
        
        // Harga satuan berdasarkan bibit 
        if (namaBibit.equalsIgnoreCase("Bibit Cabai")) {
            this.harga = 5000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Sawit")) {
            this.harga = 80000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Anggrek")) {
            this.harga = 10000;
        }

        // Pajak berdasarkan jenis 
        if (jenis.equalsIgnoreCase("Pohon")) {
            this.pajak = 5000;
        } else if (jenis.equalsIgnoreCase("Pangan")) {
            this.pajak = 2000;
        } else if (jenis.equalsIgnoreCase("Hias")) {
            this.pajak = 1000;
        } else {
            this.pajak = 0;
        }
    }
    @Override
    public double hitungDiskon(double totalHarga) {
        // Jika total belanja bibit di atas Rp 100.000, dapat diskon 10%
        if (totalHarga > 100000) {
            return totalHarga * 0.10;
        }
        return 0;
    }

    @Override
    public String getInfoDetail() {
        return "Produk Bibit Tanaman Berkualitas Unggul tipe " + jenisTanaman;
    }
    
    @Override
    public boolean cekStokSedia(int jumlahDiminta) {
        // Simulasi stok konstan di gudang ada 100 Bibit
        int stokGudang = 100; 
        return jumlahDiminta <= stokGudang;
    }
    
    public double getTotalHarga(int jumlah) {
        return (this.harga * jumlah) + this.pajak;
    }
    
    public String JenisTanaman(){
       return jenisTanaman;
    }
    public double Pajak(){
       return pajak;
    }
    public String namaBibit(){
        return namaBibit;
    }
}