/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas6;

/**
 *
 * @author Febri
 */
public class Main {
    public static void main(String[] args) {
        Produk produk1 = new Bibit();
        
        ((Bibit) produk1).setProduk("Bibit Sawit", "Pohon");
        
        System.out.println("--- Detail Produk 1 (Bibit) ---");
        // Menampilkan data spesifik yang hanya ada di kelas Bibit
        System.out.println("Nama Bibit : " + ((Bibit) produk1).namaBibit);
        System.out.println("Harga Bibit : " + ((Bibit) produk1).harga);
        System.out.println("Jenis Tanaman: " + ((Bibit) produk1).JenisTanaman());
        System.out.println("Pajak        : " + ((Bibit) produk1).Pajak());
        System.out.println();
        
        
        Pupuk produk2 = new Pupuk();
        produk2.setProduk("Pupuk Organik Super", "10 kg");
        
        System.out.println("--- Detail Produk 2 (Pupuk) ---");
        System.out.println("Nama Pupuk : " + produk2.namaPupuk);
        System.out.println("Ukuran Berat : " + produk2.kilo);
        System.out.println("Harga : " + produk2.harga);
        System.out.println();
    }
}
