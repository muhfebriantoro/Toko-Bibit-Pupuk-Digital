/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk {
    private String jenisTanaman;
    private double pajak;
    
    @Override
    public void setProduk(String namaBibit, double jumlah) {
        // Mengisi atribut nama yang diwarisi dari superclass
        this.nama = namaBibit; 

        if (namaBibit.equalsIgnoreCase("Bibit Cabai")) {
            this.harga = 5000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Sawit")) {
            this.harga = 80000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Anggrek")) {
            this.harga = 10000;
        } else {
            this.harga = 0;
        }

        if (namaBibit.equalsIgnoreCase("Bibit Sawit")) {
            this.jenisTanaman = "Pohon";
        } else if (namaBibit.equalsIgnoreCase("Bibit Cabai")) {
            this.jenisTanaman = "Pangan";
        } else if (namaBibit.equalsIgnoreCase("Bibit Anggrek")) {
            this.jenisTanaman = "Hias";
        } else {
            this.jenisTanaman = "Umum";
        }

        if (this.jenisTanaman.equalsIgnoreCase("Pohon")) {
            this.pajak = 5000;
        } else if (this.jenisTanaman.equalsIgnoreCase("Pangan")) {
            this.pajak = 2000;  
        } else if (this.jenisTanaman.equalsIgnoreCase("Hias")) {
            this.pajak = 1000;
        } else {
            this.pajak = 0;
        }

        this.harga = (this.harga * jumlah) + this.pajak;
    }

    // Method tambahan spesifik kelas Bibit
    public String getJenisTanaman() {
        return this.jenisTanaman;
    }

    public double getPajak() {
        return this.pajak;
    }
}
