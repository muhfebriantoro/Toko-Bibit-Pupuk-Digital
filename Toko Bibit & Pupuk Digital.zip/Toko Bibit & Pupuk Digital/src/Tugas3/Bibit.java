/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas3;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk {
    String jenisTanaman;
    double pajak;
    
    public void setBibit(String nama, String jenis, int jumlah) {
        this.nama = nama;
        this.jenisTanaman = jenis;
        
        // Logika harga berdasarkan nama (Sesuai gambar Anda)
        if (nama.equalsIgnoreCase("Bibit Cabai")) this.harga = 5000;
        else if (nama.equalsIgnoreCase("Bibit Sawit")) this.harga = 80000;
        else if (nama.equalsIgnoreCase("Bibit Anggrek")) this.harga = 10000;

        // Logika pajak berdasarkan jenis
        if (jenis.equalsIgnoreCase("Pohon")) this.pajak = 5000;
        else if (jenis.equalsIgnoreCase("Pangan")) this.pajak = 2000;
        else this.pajak = 1000;

        this.harga = (this.harga * jumlah) + this.pajak;
    }
    
    public double getPajak() { 
        return pajak; 
    }
    public String getJenis() { 
        return jenisTanaman; 
    }
}
