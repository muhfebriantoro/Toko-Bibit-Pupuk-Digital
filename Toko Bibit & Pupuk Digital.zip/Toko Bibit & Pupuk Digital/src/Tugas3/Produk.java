/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas3;

/**
 *
 * @author Febri
 */
public class Produk {
    String nama;
    double harga;

    // Method Original
    public void setProduk(String nama, double harga) {
        this.nama = nama;
        this.harga = harga;
    }

    // OVERLOADING: Method dengan nama sama, parameter berbeda
    public void setProduk(String nama) {
        this.nama = nama;
        this.harga = 0; 
    }
}