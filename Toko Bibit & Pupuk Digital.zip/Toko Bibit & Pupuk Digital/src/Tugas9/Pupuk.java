/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas9;

/**
 *
 * @author Febri
 */
class Pupuk extends Produk implements Diskon, StokBarang, DeskripsiProduk{
  
    String namaPupuk;
    String kilo;
    
    @Override
    public void setProduk(String nama, String jenis){
        this.nama = nama;
        this.kilo = jenis;
                
        // ===== Tentukan harga berdasarkan berat =====
        if (kilo.equalsIgnoreCase("5 kg")) {
            this.harga = 50000;
        } else if (kilo.equalsIgnoreCase("10 kg")) {
            this.harga = 100000;
        }
    }
    @Override
    public double hitungDiskon(double totalHarga) {
        // Jika total belanja Pupuk di atas Rp 100.000, dapat diskon 10%
        if (totalHarga > 100000) {
            return totalHarga * 0.10;
        }
        return 0;
    }
    
    @Override
    public boolean cekStokSedia(int jumlahDiminta) {
        // Simulasi stok konstan di gudang ada 20 karung
        int stokGudang = 20; 
        return jumlahDiminta <= stokGudang;
    }

    @Override
    public String getInfoDetail() {
        return "Pupuk Organik Subur Kaya Nutrisi kemasan " + kilo;
    }
    
}
