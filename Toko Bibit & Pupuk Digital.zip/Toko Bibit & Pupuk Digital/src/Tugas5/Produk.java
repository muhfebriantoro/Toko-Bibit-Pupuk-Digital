/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Febri
 */
public class Produk {
    // Menggunakan protected agar bisa diakses langsung oleh kelas turunannya
    protected String nama;   
    protected double harga;

    // Method standar di kelas induk yang akan di-override oleh kelas anak
    public void setProduk(String nama, double harga,double jumlah) {
        this.nama = nama;
        this.harga = harga;
    }
    
    // Getter untuk mengambil nilai harga
    public double getHarga() {
        return this.harga;
    }
    
    public void setProduk(String nama, double harga) {
        this.nama = nama;
        this.harga = harga;
    }
}