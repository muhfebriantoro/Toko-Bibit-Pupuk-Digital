/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas4;

/**
 *
 * @author Febri
 */
public class Produk {
    private String nama;
    private double harga;

    // Getter dan Setter untuk mengakses variabel private
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    // Method Original
    public void setProduk(String nama, double harga) {
        this.nama = nama; // Bisa langsung akses atribut karena berada di kelas yang sama
        this.harga = harga;
    }

    // OVERLOADING: Method dengan nama sama, parameter berbeda
    public void setProduk(String nama) {
        this.nama = nama;
        this.harga = 0; 
    }
}
