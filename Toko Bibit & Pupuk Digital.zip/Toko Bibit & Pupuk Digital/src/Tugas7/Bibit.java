/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas7;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk{
    String namaBibit, jenisTanaman;
    double pajak;
            
    @Override
    public void setProduk(String namaBibit, String jenis){
        this.namaBibit = namaBibit;
        this.jenisTanaman = jenis;     
        
        // Harga satuan berdasarkan bibit 
        if (namaBibit.equalsIgnoreCase("Bibit Cabai")) {
            this.harga = 5000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Sawit")) {
            this.harga = 80000;
        } else if (namaBibit.equalsIgnoreCase("Bibit Anggrek")) {
            this.harga = 10000;
        }

        // Pajak berdasarkan jenis 
        if (jenis.equalsIgnoreCase("Pohon")) {
            this.pajak = 5000;
        } else if (jenis.equalsIgnoreCase("Pangan")) {
            this.pajak = 2000;
        } else if (jenis.equalsIgnoreCase("Hias")) {
            this.pajak = 1000;
        } else {
            this.pajak = 0;
        }
    }
    
    public double getTotalHarga(int jumlah) {
        return (this.harga * jumlah) + this.pajak;
    }
    
    public String JenisTanaman(){
       return jenisTanaman;
    }
    public double Pajak(){
       return pajak;
    }
    public String namaBibit(){
        return namaBibit;
    }
}