/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas4;

/**
 *
 * @author Febri
 */
public class Bibit extends Produk {
    private String jenisTanaman;
    private double pajak;
    
    public void setBibit(String nama, String jenis, int jumlah) {
        setNama(nama);
        this.jenisTanaman = jenis;
        
        double harga = 0;
        
        if (nama.equalsIgnoreCase("Bibit Cabai")) harga = 5000;
        else if (nama.equalsIgnoreCase("Bibit Sawit")) harga = 80000;
        else if (nama.equalsIgnoreCase("Bibit Anggrek")) harga = 10000;

        if (jenis.equalsIgnoreCase("Pohon")) this.pajak = 5000;
        else if (jenis.equalsIgnoreCase("Pangan")) this.pajak = 2000;
        else this.pajak = 1000;

        // Setter untuk menyimpan harga
        setHarga((harga * jumlah) + this.pajak);
    }
    
    // Getter
    public double getPajak() { 
        return pajak; 
    }
    
    public String getJenis() { 
        return jenisTanaman; 
    }

    // Setter untuk variabel private di subclass ini
    public void setJenisTanaman(String jenisTanaman) {
        this.jenisTanaman = jenisTanaman;
    }

    public void setPajak(double pajak) {
        this.pajak = pajak;
    }
}
